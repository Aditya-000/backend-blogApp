const mongoose = require("mongoose");
require("dotenv").config();

const connectWithDB = () => {
    mongoose.connect(process.env.DB_URL,{
        useNewUrlParser: true,
        useUnifiedTopology:true,
    })
    .then(console.log("Db connected"))
    .catch( (err) => {
        console.log("DB connection failed");
        process.exit(1);
    })
};

module.exports = connectWithDB;