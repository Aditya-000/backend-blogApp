const express = require("express");
const app = express();
app.use(express.json());
require("dotenv").config();


const blog = require("./routes/blog");


app.use("/api/v1",blog);

const connectWithDB = require("./config/database");
connectWithDB();


app.get("/", (req,res) => {
    res.send(`<h1>This is the home page </h1>`);
})

app.listen(process.env.PORT || 3000, () => {
    console.log("server running");
})


