const Like = require("../models/likemodels");
const Post = require("../models/postmodel");

//like a post

exports.likePost = async (req,res) =>{
    try{
        const{post,user} = req.body;
        const like = new Like({
            post,user,
        })

        const savedLike = await like.save();

        const updatePost = await Post.findByIdAndUpdate(post,{$push: {likes: savedLike._id}},{new:true})
        .populate("likes").exec();
        
        res.json({
            post:updatePost,
        })
    }
    catch(error){
        return res.status(400).json({
            error:"Error for like",
           })
    }
};


//unlike a post
exports.unLikePost = async (req,res) =>{
    try{
         const{post,like} = req.body;

         //find and delete from like
         const deletedLike = await Like.findOneAndDelete({
            post:post,
            _id:like,
         })

         //update post collection
         const updatedPost = await Post.findByIdAndDelete(post, {$pull: {likes:deletedLike._id}},{new:true})
          res.json({
            post:updatedPost,
          })
    }
    catch(error){
        return res.status(400).json({
            error:"Error for unlike",
           })
    }
};